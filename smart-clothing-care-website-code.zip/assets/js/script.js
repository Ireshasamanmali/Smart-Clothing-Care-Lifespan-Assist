/**
 * Smart Clothing Care & Lifespan Assistant - JavaScript Engine
 * Dynamic interactions, image upload handling, and API integration
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initImageUploads();
    initAnalysisForm();
    initWeatherGuidance();
    initDamageAnalysis();
    initReminders();
    initContactForm();
});

// Smooth Scroll & Active Nav
function initNavigation() {
    const links = document.querySelectorAll('.nav-links a');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// Image Drag & Drop Preview
function initImageUploads() {
    setupUploadBox('clothingUploadBox', 'clothingImageInput', 'clothingPreview');
    setupUploadBox('damageUploadBox', 'damageImageInput', 'damagePreview');
}

function setupUploadBox(boxId, inputId, previewId) {
    const box = document.getElementById(boxId);
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);

    if (!box || !input) return;

    box.addEventListener('click', () => input.click());

    box.addEventListener('dragover', (e) => {
        e.preventDefault();
        box.style.borderColor = '#2D4A3E';
        box.style.backgroundColor = '#DDE8E2';
    });

    box.addEventListener('dragleave', () => {
        box.style.borderColor = '#7A9A8B';
        box.style.backgroundColor = '#EBF2EE';
    });

    box.addEventListener('drop', (e) => {
        e.preventDefault();
        box.style.borderColor = '#7A9A8B';
        box.style.backgroundColor = '#EBF2EE';
        if (e.dataTransfer.files.length) {
            input.files = e.dataTransfer.files;
            handleImagePreview(input.files[0], preview);
        }
    });

    input.addEventListener('change', () => {
        if (input.files.length) {
            handleImagePreview(input.files[0], preview);
        }
    });
}

function handleImagePreview(file, previewElement) {
    if (!previewElement) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        previewElement.innerHTML = `<img src="${e.target.result}" style="max-height: 200px; border-radius: 8px; margin-top: 10px;" alt="Uploaded Preview">`;
    };
    reader.readAsDataURL(file);
}

// Clothing Information Analysis Form Submission
function initAnalysisForm() {
    const form = document.getElementById('clothingAnalysisForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const resultsContainer = document.getElementById('analysisResults');

        resultsContainer.innerHTML = '<p style="text-align:center;">🔍 Analyzing fabric structure & generating care recommendations...</p>';
        resultsContainer.style.display = 'block';

        try {
            const response = await fetch('api/analyze.php', {
                method: 'POST',
                body: formData
            });
            const res = await response.json();

            if (res.status === 'success') {
                renderAnalysisResults(res.data, resultsContainer);
            } else {
                resultsContainer.innerHTML = `<p style="color:red;">${res.message}</p>`;
            }
        } catch (err) {
            // Client-side fallback if PHP environment is offline
            simulateLocalAnalysis(formData, resultsContainer);
        }
    });
}

function renderAnalysisResults(data, container) {
    container.innerHTML = `
        <h3>🧺 Care Recommendation for ${data.category} (${data.fabric})</h3>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <div><strong>Washing Method:</strong> ${data.washing}</div>
            <div><strong>Water Temperature:</strong> ${data.water_temp}</div>
            <div><strong>Detergent:</strong> ${data.detergent}</div>
            <div><strong>Drying Method:</strong> ${data.drying}</div>
            <div><strong>Ironing Setting:</strong> ${data.ironing}</div>
            <div><strong>Storage Advice:</strong> ${data.storage}</div>
        </div>
        <div style="margin-top: 1rem; background: #EBF2EE; padding: 1rem; border-radius: 8px;">
            <strong>💧 Monsoon / Humidity Alert:</strong> ${data.humidity_tip}
        </div>
    `;
}

function simulateLocalAnalysis(formData, container) {
    const fabric = formData.get('fabric') || 'Cotton';
    const category = formData.get('category') || 'Garment';

    let advice = {
        category: category,
        fabric: fabric,
        washing: fabric === 'Silk' ? 'Cold hand wash with delicate liquid detergent' : 'Machine wash inside out in cold water (30°C)',
        water_temp: 'Cold water (30°C) to prevent dye fading and fiber hydrolysis',
        detergent: 'Mild liquid detergent (avoid excess powder detergent to prevent stiff residue)',
        drying: 'Air dry on wide hangers in shaded area with good air circulation',
        ironing: fabric === 'Silk' ? 'Low heat (110°C) on reverse side' : 'Medium-high heat (150-180°C) with steam',
        storage: 'Store in well-ventilated wardrobe with 2 inches space between garments',
        humidity_tip: 'Ensure 100% dryness at thick seams before putting into closets to prevent mold spores.'
    };
    renderAnalysisResults(advice, container);
}

// Weather Guidance Dynamic Selector
function initWeatherGuidance() {
    const weatherSelect = document.getElementById('weatherSelect');
    const weatherDisplay = document.getElementById('weatherDisplay');

    if (!weatherSelect || !weatherDisplay) return;

    weatherSelect.addEventListener('change', async () => {
        const condition = weatherSelect.value;
        try {
            const res = await fetch(`api/weather.php?condition=${encodeURIComponent(condition)}`);
            const data = await res.json();
            renderWeatherDisplay(data.data, weatherDisplay);
        } catch (err) {
            simulateLocalWeather(condition, weatherDisplay);
        }
    });
}

function renderWeatherDisplay(data, container) {
    container.innerHTML = `
        <div class="card" style="border-left: 5px solid #0284C7; margin-top: 1rem;">
            <h4>🌧️ Care Strategy: ${data.condition}</h4>
            <p><strong>Drying Recommendation:</strong> ${data.drying_strategy}</p>
            <p><strong>Storage Strategy:</strong> ${data.storage_strategy}</p>
            <p style="color:#92400E; margin-top: 0.5rem;"><strong>🛡️ Fungal & Odor Prevention:</strong> ${data.mold_tip}</p>
        </div>
    `;
}

function simulateLocalWeather(condition, container) {
    const dataMap = {
        'Rainy': {
            condition: 'Rainy / Monsoon Season',
            drying_strategy: 'Indoor drying with dehumidifier or oscillating fan. Apply an extra spin cycle in machine.',
            storage_strategy: 'Space hangers 2-3 inches apart. Use breathable cotton bags.',
            mold_tip: 'Ensure garments are 100% dry before closet storage. Use silica gel packets.'
        },
        'High Humidity': {
            condition: 'High Humidity Weather',
            drying_strategy: 'Shade drying with active cross-ventilation. Do not hang damp clothes against damp walls.',
            storage_strategy: 'Open closet doors during sunny mornings to air out wardrobes.',
            mold_tip: 'Wipe wardrobe shelves with diluted vinegar solution to eliminate spores.'
        }
    };
    const fallback = dataMap[condition] || dataMap['Rainy'];
    renderWeatherDisplay(fallback, container);
}

// Damage Identification & Repair Recommendations
function initDamageAnalysis() {
    const form = document.getElementById('damageForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const damageType = document.getElementById('damageType').value;
        const resultBox = document.getElementById('damageResult');
        resultBox.style.display = 'block';

        let advice = '';
        if (damageType === 'Stain') {
            advice = '<strong>Stain Removal:</strong> Treat immediately with cold water and liquid detergent. For oil stains, apply cornstarch before laundering. Avoid hot water which sets protein stains.';
        } else if (damageType === 'Tear') {
            advice = '<strong>Fabric Repair:</strong> Perform a neat ladder stitch on seams. Apply lightweight iron-on fusible interfacing on the reverse side before stitching small tears.';
        } else if (damageType === 'Mold') {
            advice = '<strong>Fungal Mold Treatment:</strong> Soak in cold water with diluted white vinegar (1:4 ratio) or ozone wash. Line dry in sunlight to kill fungal spores.';
        } else {
            advice = '<strong>Color Fading:</strong> Wash garments inside out in cold water. Soak in salt-water rinse before first wash to set color dyes.';
        }

        resultBox.innerHTML = `
            <h4>🔧 AI Repair & Restoration Guide</h4>
            <p>${advice}</p>
            <span class="badge" style="margin-top:0.5rem;">Note: AI Image Recognition Integration Point</span>
        `;
    });
}

// Care Reminders Manager
function initReminders() {
    const form = document.getElementById('reminderForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('reminderTitle').value;
        const date = document.getElementById('reminderDate').value;
        const category = document.getElementById('reminderCategory').value;

        const list = document.getElementById('remindersList');
        const item = document.createElement('div');
        item.className = 'reminder-item';
        item.innerHTML = `
            <div>
                <strong>${title}</strong> (${category})
                <br><small style="color:#6B7280;">Scheduled: ${date}</small>
            </div>
            <button class="btn btn-secondary" onclick="this.parentElement.remove()" style="padding:0.4rem 0.8rem; font-size:0.8rem;">Complete</button>
        `;
        list.prepend(item);
        form.reset();
    });
}

// Contact Form Handler
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Thank you for contacting Smart Clothing Care Sri Lanka! We have received your message.');
        form.reset();
    });
}
